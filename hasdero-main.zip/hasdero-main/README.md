# MINING-DOCKER
edit di startbot.sh && Dockerfile

forks edit sesuai keterangan di atas depoly di apps heroku

![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)



